# Servidor de Interconexión Brothers (Almacén ↔ Venta)

Servidor backend Node.js + Express diseñado para desplegarse **gratis en Render (render.com)**.  
Conecta de forma centralizada la aplicación de inventario **Brothers Almacén** con la aplicación móvil **Brothers Venta**.

---

## 🚀 Cómo Desplegar en Render (Paso a Paso en 3 Minutos)

### Paso 1: Subir este proyecto a GitHub
1. Crea un nuevo repositorio en GitHub llamado `brothers-servidor` (o el nombre que prefieras).
2. Sube los archivos de esta carpeta (`package.json`, `server.js`, `render.yaml`).

### Paso 2: Crear el servicio en Render
1. Ve a [dashboard.render.com](https://dashboard.render.com) e inicia sesión (puedes entrar con tu cuenta de GitHub).
2. Haz clic en el botón azul **"New +"** y selecciona **"Web Service"**.
3. Elige tu repositorio de GitHub recién creado (`brothers-servidor`).
4. Configura los datos básicos:
   - **Name**: `brothers-sync-servidor` (o el que desees).
   - **Region**: Oregon (US West) o Frankfurt.
   - **Branch**: `main`.
   - **Runtime**: `Node`.
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Instance Type**: **Free** (Gratuito).
5. Haz clic en **"Deploy Web Service"**.

Render compilará tu servidor y en menos de 2 minutos te dará una URL pública como:  
👉 **`https://brothers-sync-servidor.onrender.com`**

---

## 📱 Cómo Conectar en Brothers Venta
1. Abre **Brothers Venta**.
2. En la pantalla de inicio de sesión o en **Ajustes > Servidor Render**, escribe la URL de tu servidor:  
   `https://tu-servidor.onrender.com`
3. ¡Listo! Ya podrás iniciar sesión con las vendedoras creadas desde Brothers Almacén y enviar informes en tiempo real.

---

## 👥 Usuarios de Prueba Autorizados (Por Defecto)
El servidor viene preconfigurado con usuarios autorizados de muestra:
- **Usuario**: `vendedora1` | **Contraseña**: `1234`
- **Usuario**: `vendedora2` | **Contraseña**: `1234`
- **Usuario**: `admin` | **Contraseña**: `password123`

---

## 📡 Endpoints del Servidor

| Método | Endpoint | Descripción |
|---|---|---|
| `GET` | `/api/health` | Comprobación de estado del servidor |
| `POST` | `/api/auth/login` | Inicia sesión de vendedoras |
| `POST` | `/api/almacen/create-user` | **Brothers Almacén crea y autoriza una nueva vendedora** |
| `GET` | `/api/almacen/users` | Lista las vendedoras creadas por Almacén |
| `DELETE` | `/api/almacen/users/:id` | Elimina una vendedora |
| `GET` | `/api/sync/products` | Venta descarga el catálogo y stock actualizado |
| `POST` | `/api/sync/products` | Almacén actualiza el catálogo y existencias |
| `POST` | `/api/sync/sales` | Venta reporta ventas y descuenta inventario |
| `POST` | `/api/sync/reports` | Venta envía el informe al administrador |
| `GET` | `/api/sync/reports` | Almacén revisa los informes recibidos |
