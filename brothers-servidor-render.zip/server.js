import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 10000;

// Configuración de CORS amplia para aplicaciones móviles y navegadores
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json({ limit: '10mb' }));

// Ruta a base de datos JSON persistente
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

// Inicializar base de datos con usuarios autorizados de Brothers Almacén
const INITIAL_DB = {
  users: [
    {
      id: 'usr-admin-1',
      username: 'admin',
      password: 'password123',
      name: 'Administrador Almacén',
      role: 'administrador',
      createdByAlmacen: true,
      createdAt: '2026-01-01T00:00:00.000Z'
    },
    {
      id: 'usr-vend-1',
      username: 'vendedora1',
      password: '1234',
      name: 'Vendedora 1 (Almacén Principal)',
      role: 'vendedora',
      createdByAlmacen: true,
      createdAt: '2026-01-01T00:00:00.000Z'
    },
    {
      id: 'usr-vend-2',
      username: 'vendedora2',
      password: '1234',
      name: 'Vendedora 2 (Sucursal Norte)',
      role: 'vendedora',
      createdByAlmacen: true,
      createdAt: '2026-01-01T00:00:00.000Z'
    }
  ],
  products: [
    {
      id: 'prod-1',
      name: 'Aceite Vegetal 1L',
      buyPrice: 2.50,
      sellPrice: 3.80,
      stock: 24,
      category: 'Abarrotes'
    },
    {
      id: 'prod-2',
      name: 'Refresco Cola 2L',
      buyPrice: 1.20,
      sellPrice: 2.00,
      stock: 35,
      category: 'Bebidas'
    },
    {
      id: 'prod-3',
      name: 'Detergente en Polvo 1kg',
      buyPrice: 1.80,
      sellPrice: 2.90,
      stock: 18,
      category: 'Limpieza'
    }
  ],
  sales: [],
  reports: []
};

// Funciones de lectura y guardado
function getDB() {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(DB_FILE)) {
      fs.writeFileSync(DB_FILE, JSON.stringify(INITIAL_DB, null, 2), 'utf8');
      return INITIAL_DB;
    }
    const data = fs.readFileSync(DB_FILE, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Error al leer base de datos:', err);
    return INITIAL_DB;
  }
}

function saveDB(db) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf8');
  } catch (err) {
    console.error('Error al guardar base de datos:', err);
  }
}

// -------------------------------------------------------------
// 1. HEALTHCHECK Y STATUS (Utilizado por Render y la app para test)
// -------------------------------------------------------------
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    server: 'Brothers Sync Server (Render)',
    version: '1.2.0',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

app.get('/', (req, res) => {
  res.send(`
    <html>
      <head>
        <title>Brothers Sync Server - Activo</title>
        <style>
          body { font-family: system-ui, sans-serif; background: #0f172a; color: #f8fafc; padding: 2rem; text-align: center; }
          .card { background: #1e293b; padding: 2rem; border-radius: 1rem; max-width: 600px; margin: 0 auto; border: 1px solid #334155; }
          h1 { color: #10b981; margin-bottom: 0.5rem; }
          .status { display: inline-block; background: #064e3b; color: #34d399; padding: 0.25rem 0.75rem; border-radius: 9999px; font-weight: bold; font-size: 0.875rem; }
          ul { text-align: left; background: #0f172a; padding: 1rem 2rem; border-radius: 0.5rem; }
        </style>
      </head>
      <body>
        <div class="card">
          <h1>Servidor de Interconexión Brothers</h1>
          <p class="status">● Activo y Operativo en Render</p>
          <p>Conexión entre <strong>Brothers Almacén</strong> y <strong>Brothers Venta</strong>.</p>
          <ul>
            <li><strong>POST /api/auth/login</strong> - Inicio de sesión para vendedoras</li>
            <li><strong>POST /api/almacen/create-user</strong> - Registro de vendedoras desde Almacén</li>
            <li><strong>GET /api/almacen/users</strong> - Lista de usuarios de Almacén</li>
            <li><strong>GET /api/sync/products</strong> - Catálogo de productos y stock sincronizado</li>
            <li><strong>POST /api/sync/sales</strong> - Registro de ventas móvil</li>
            <li><strong>POST /api/sync/reports</strong> - Recepción de informes al Administrador</li>
          </ul>
        </div>
      </body>
    </html>
  `);
});

// -------------------------------------------------------------
// 2. AUTENTICACIÓN (LOGIN EXCLUSIVO PARA USUARIOS DE ALMACÉN)
// -------------------------------------------------------------
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({
      success: false,
      message: 'Debes ingresar usuario y contraseña.'
    });
  }

  const db = getDB();
  const cleanUsername = username.trim().toLowerCase();

  // Buscar usuario
  const user = db.users.find(u => 
    u.username.trim().toLowerCase() === cleanUsername && 
    u.password === password.trim()
  );

  if (!user) {
    return res.status(401).json({
      success: false,
      message: 'Credenciales inválidas. Verifica tu usuario y contraseña.'
    });
  }

  // REGLA FUNDAMENTAL: Solo permitir acceso si fue creado desde Brothers Almacén
  if (!user.createdByAlmacen) {
    return res.status(403).json({
      success: false,
      message: 'Acceso denegado: Este usuario no tiene autorización creada desde Brothers Almacén.'
    });
  }

  // Generar token de sesión
  const token = 'tok_' + Date.now() + '_' + Math.random().toString(36).substring(2, 9);

  return res.json({
    success: true,
    message: 'Inicio de sesión exitoso.',
    token,
    user: {
      id: user.id,
      name: user.name,
      username: user.username,
      role: user.role,
      createdByAlmacen: user.createdByAlmacen,
      lastLogin: new Date().toISOString()
    }
  });
});

// -------------------------------------------------------------
// 3. GESTIÓN DE USUARIOS DESDE BROTHERS ALMACÉN
// -------------------------------------------------------------
// Crear usuario desde Almacén (Vendedora o Administrador)
app.post('/api/almacen/create-user', (req, res) => {
  const { name, username, password, role = 'vendedora' } = req.body;

  if (!name || !username || !password) {
    return res.status(400).json({
      success: false,
      message: 'Faltan campos obligatorios: name, username, password.'
    });
  }

  const db = getDB();
  const cleanUsername = username.trim().toLowerCase();

  // Verificar si ya existe
  if (db.users.some(u => u.username.toLowerCase() === cleanUsername)) {
    return res.status(400).json({
      success: false,
      message: `El usuario "${cleanUsername}" ya existe en el sistema.`
    });
  }

  const newUser = {
    id: 'usr-' + Date.now(),
    name: name.trim(),
    username: cleanUsername,
    password: password.trim(),
    role: role === 'administrador' ? 'administrador' : 'vendedora',
    createdByAlmacen: true, // Marcado oficial de creación en Almacén
    createdAt: new Date().toISOString()
  };

  db.users.push(newUser);
  saveDB(db);

  return res.status(201).json({
    success: true,
    message: `Vendedora "${newUser.name}" creada y autorizada exitosamente desde Almacén.`,
    user: {
      id: newUser.id,
      name: newUser.name,
      username: newUser.username,
      role: newUser.role,
      createdByAlmacen: newUser.createdByAlmacen
    }
  });
});

// Listar todos los usuarios creados en Almacén
app.get('/api/almacen/users', (req, res) => {
  const db = getDB();
  // Devolver sin las contraseñas
  const sanitizedUsers = db.users.map(({ password, ...rest }) => rest);
  res.json({
    success: true,
    total: sanitizedUsers.length,
    users: sanitizedUsers
  });
});

// Eliminar un usuario
app.delete('/api/almacen/users/:id', (req, res) => {
  const { id } = req.params;
  const db = getDB();

  const initialCount = db.users.length;
  db.users = db.users.filter(u => u.id !== id);

  if (db.users.length === initialCount) {
    return res.status(404).json({ success: false, message: 'Usuario no encontrado.' });
  }

  saveDB(db);
  return res.json({ success: true, message: 'Usuario eliminado correctamente.' });
});

// -------------------------------------------------------------
// 4. SINCRONIZACIÓN DE PRODUCTOS Y STOCK (ALMACÉN -> VENTA)
// -------------------------------------------------------------
app.get('/api/sync/products', (req, res) => {
  const db = getDB();
  res.json({
    success: true,
    products: db.products,
    updatedAt: new Date().toISOString()
  });
});

app.post('/api/sync/products', (req, res) => {
  const { products } = req.body;
  if (!Array.isArray(products)) {
    return res.status(400).json({ success: false, message: 'Se esperaba un array de productos.' });
  }

  const db = getDB();
  db.products = products;
  saveDB(db);

  res.json({
    success: true,
    message: 'Catálogo de productos sincronizado con éxito desde Almacén.',
    total: products.length
  });
});

// -------------------------------------------------------------
// 5. REGISTRO Y ENVÍO DE VENTAS (VENTA -> ALMACÉN)
// -------------------------------------------------------------
app.post('/api/sync/sales', (req, res) => {
  const { sale } = req.body;
  if (!sale || !sale.items) {
    return res.status(400).json({ success: false, message: 'Datos de venta incompletos.' });
  }

  const db = getDB();
  db.sales.push({
    ...sale,
    receivedAt: new Date().toISOString()
  });

  // Descontar inventario automáticamente si coincide
  if (Array.isArray(sale.items)) {
    sale.items.forEach(soldItem => {
      const prod = db.products.find(p => p.id === soldItem.productId);
      if (prod) {
        prod.stock = Math.max(0, (prod.stock || 0) - soldItem.quantity);
      }
    });
  }

  saveDB(db);

  res.json({
    success: true,
    message: 'Venta registrada y stock actualizado en el servidor de Almacén.',
    saleId: sale.id
  });
});

app.get('/api/sync/sales', (req, res) => {
  const db = getDB();
  res.json({
    success: true,
    total: db.sales.length,
    sales: db.sales
  });
});

// -------------------------------------------------------------
// 6. INFORMES DE VENTAS (ENVIAR AL ADMINISTRADOR)
// -------------------------------------------------------------
app.post('/api/sync/reports', (req, res) => {
  const { report, sellerName, sellerId } = req.body;
  if (!report) {
    return res.status(400).json({ success: false, message: 'Falta el cuerpo del informe.' });
  }

  const db = getDB();
  const savedReport = {
    ...report,
    sellerName: sellerName || 'Vendedora',
    sellerId: sellerId || 'usr-anon',
    receivedAt: new Date().toISOString(),
    status: 'recibido_por_administrador'
  };

  db.reports.unshift(savedReport);
  saveDB(db);

  res.json({
    success: true,
    message: `Informe #${report.reportNumber} recibido con éxito por el Administrador de Brothers Almacén.`,
    reportId: savedReport.id
  });
});

app.get('/api/sync/reports', (req, res) => {
  const db = getDB();
  res.json({
    success: true,
    total: db.reports.length,
    reports: db.reports
  });
});

// Iniciar servidor
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Servidor de interconexión Brothers iniciado en el puerto ${PORT}`);
});
